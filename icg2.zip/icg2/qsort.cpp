#include<bits/stdc++.h>
// using namespace std;

int part(vector<int> arr,int low,int high)
{
  //choose the pivot
  int pivot=arr[high];
  //Index of smaller element and Indicate
  //the right position of pivot found so far
  int i = (low-1);
  
  for(int j=low;j<=high;j++)
  {
    //If current element is smaller than the pivot
    if(arr[j]<pivot)
    {
      //Increment index of smaller element
      i++;
      int temp1 = arr[i];
      arr[i] = arr[j];
      arr[j] = temp1;
    }
  }
  int temp1 = arr[i+1];
  arr[i+1] = arr[high];
  arr[high] = temp1;
  return (i+1);
}

// The qsort function Implement
           
void qsort(vector<int> arr,int low,int high){
  // when low is less than high
  if(low<high)
  {
    // pi is the part return index of pivot
    
    int pi = part(arr,low,high);
    
    //Recursion Call
    //smaller element than pivot goes left and
    //higher element goes right
    qsort(arr,low,pi-1);
    qsort(arr,pi+1,high);
  }
  
}
             
int main() {
  vector<int> arr{10,7,8,9,1,5};
  int n = arr.size();
  // Function call
  qsort(arr,0,n);
  //Print the sorted array
  cout<<"Sorted Array\n";
  for(int i=0;i<n;i++)
  {
    cout<<arr[i]<<" ";
  }
  return 0;
}
// This Code is Contributed By Diwakar Jha
