#include<bits/stdc++.h>

int function(int x, int y){

}

int main(){
    int a = 5,d; // inherited variable a, d;
    cin>>a;
    int e = 10;
    char c = 'c';
    for(int i=0;i<10;i++){d = 1;
    }
    if(b == 10) {    // undeclared variable b
        a = 10;
    }
    int a = 8; // redeclaration of variable a
    
    int x = 11;
    x();
    string s = "hello"; 
    c = (s*10); // mismatched datatypes in expression

    int int = 13; // keyword used as variable name 

    function(a,b,c); // function call mismatched based on number of arguments

    return 0;
}



/* undeclared usage of variables and functions , Multiple declarations, Mismatched datatypes of variables in expressions, function call mismatched based on number of arguments */